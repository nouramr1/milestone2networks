package networks;
import java.io.*;
import java.net.*;


public class TCPClient {

	    public static void main(String args[]) throws Exception 
	    { 
	        String sentence; 
	        String modifiedSentence; 

	        BufferedReader inFromUser = 
	          new BufferedReader(new InputStreamReader(System.in)); 
	        
	        sentence=inFromUser.readLine();
	        if(sentence.equals("CONNECT")) {
	        	
	        

	        Socket clientSocket = new Socket("127.0.0.1", 6789); 
	    
	        DataOutputStream outToServer = 
	          new DataOutputStream(clientSocket.getOutputStream());
	        BufferedReader inFromServer = 
	                new BufferedReader(new
	                InputStreamReader(clientSocket.getInputStream())); 
	        System.out.println("CONNECTION ESTABLISHED");
	        System.out.println("client can send new message");
	              sentence = inFromUser.readLine(); 

	              outToServer.writeBytes(sentence + '\n'); 
	              while (true) {
	            	  
	              

	              modifiedSentence = inFromServer.readLine(); 

	              System.out.println("FROM SERVER: " + modifiedSentence);
	              System.out.println("message from server");
	              sentence=inFromUser.readLine();

	             // clientSocket.close(); 
	              if(sentence.equals("END")) {
	            	  System.out.println("end chat");
	            	  outToServer.writeBytes(sentence+'\n');
	            	  outToServer.close();
	            	  break;
	              }
	              outToServer.writeBytes(sentence+'\n');
	              }
	        }
	        else {
	        	System.out.print("ERROR");
	        }
	              
	             
	              



}
}
